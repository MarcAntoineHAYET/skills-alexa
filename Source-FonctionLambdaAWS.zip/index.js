const Alexa = require('ask-sdk-core');
var https = require('https');
var http = require('http');
const qs = require('querystring');


const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
  },
  handle(handlerInput) {
    // Our skill will receive a LaunchRequest when the user invokes the skill
    // with the  invocation name, but does not provide any utterance
    // mapping to an intent.
    // For Example, "Open code academy"
    const speakOutput = 'Bienvenue sur la Skill Domo Santé';

    // The response builder contains is an object that handles generating the
    // JSON response that your skill returns.
    return handlerInput.responseBuilder
      .speak(speakOutput) // The text passed to speak, is what Alexa will say.
      .getResponse();
  },
};

const AlarmRequestHandler = {
 canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AlarmIntent';
  },
  handle(handlerInput) {
    const speakOutput = "<audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_countdown_loop_64s_full_01'/>";
    
    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  }
};

function httpGet() {
  return new Promise(((resolve, reject) => {
    var options = {
        host: 'api.icndb.com',
        port: 443,
        path: '/jokes/random',
        method: 'GET',
    };
    
    const request = https.request(options, (response) => {
      response.setEncoding('utf8');
      let returnData = '';

      response.on('data', (chunk) => {
        returnData += chunk;
      });

      response.on('end', () => {
        resolve(JSON.parse(returnData));
      });

      response.on('error', (error) => {
        reject(error);
      });
    });
    request.end();
  }));
};

function ChangePlugState(plugEtat) {
  var etat = plugEtat;
  return new Promise(((resolve, reject) => {
    var options = {
        host: 'ojbitumj.fbxos.fr',
        port: 9002,
        path: '/changer_etat/6/'+etat,
        method: 'GET',
    };
       
    const request = http.request(options, function(response) {
      response.setEncoding('utf8');
      let returnData = '{ "etat": "'+etat+'"}';
        
      response.on('data', (chunk) => {
        returnData += chunk;
      });
        
      response.on('end', () => {
        resolve(JSON.parse(returnData));
      });

      response.on('error', (error) => {
        reject(error);
      });
    });
    request.end();
  }));
};

/*function ClosePlug() {
  
  return new Promise(((resolve, reject) => {
    var options = {
        host: 'ojbitumj.fbxos.fr',
        port: 9002,
        path: '/changer_etat/6/0',
        method: 'GET',
    };
    
    const request = http.request(options, (response) => {
      response.setEncoding('utf8');
      let returnData = '{ "name": "John Doe"}';

      response.on('data', () => {
        returnData;
      });

      response.on('end', () => {
        resolve(JSON.parse(returnData));
      });

      response.on('error', (error) => {
        reject(error);
      });
    });
    request.end();
  }));
};*/

function httpPost(etat) {
  var myState = etat;
  var post_data = {"etatSanteSkillAmazon": myState};

  return new Promise(((resolve, reject) => {
    var options = {
        host: 'ojbitumj.fbxos.fr',
        port: 9002,
        path: '/reponse_skill_amazon',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
    };
    
    const request = http.request(options, function(response) {
      response.setEncoding('utf8');
      let returnData = '';

      response.on('data', (chunk) => {
        returnData += chunk;
      });

      response.on('end', () => {
        resolve(JSON.parse(returnData));
      });

      response.on('error', (error) => {
        reject(error);
      });
      /*
      context.succeed();*/
    });
    request.write(JSON.stringify(post_data));
    request.end();
  }));
};

const PostDataHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'PostDataIntent';
  },
  async handle(handlerInput) {
    const response = await httpPost();
    
    console.log(response);
    
    const speakOutput = 'Données envoyées !';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const GoodHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'goodIntent';
  },
  async handle(handlerInput) {
    const response = await httpPost(true);
    
    console.log(response);
    
    const speakOutput = 'Très bien ! Je communique que vous allez bien';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const ClosePlugHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'closeIntent';
  },
  async handle(handlerInput) {
    const response = await ChangePlugState('0');
    
    console.log(response);
    
    const speakOutput = 'Ok, jéteins la prise';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const OpenPlugHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'openIntent';
  },
  async handle(handlerInput) {
    const response = await ChangePlugState('1');
    
    console.log(response);
    
    const speakOutput = 'Ok, jallume la prise';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const BadHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'badIntent';
  },
  async handle(handlerInput) {
    const response = await httpPost(false);
    
    console.log(response);
    
    const speakOutput = "Daccord jappel les urgences: <audio src='soundbank://soundlibrary/ui/gameshow/amzn_ui_sfx_gameshow_countdown_loop_64s_full_01'/>";

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const GetJokeHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return  handlerInput.requestEnvelope.request.type === 'IntentRequest'
      &&  handlerInput.requestEnvelope.request.intent.name === 'GetJokeIntent';
  },
  async handle(handlerInput) {
    const response = await httpGet();
    
    console.log(response);

    return handlerInput.responseBuilder
            .speak("Okay. Here is what I got back from my request. " + response.value.joke)
            .reprompt("What would you like?")
            .getResponse();
  },
};

const HelloHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'HelloIntent';
  },
  handle(handlerInput) {
    // This is text that Alexa will speak back
    // when the user says, "Ask code academy to say hello"
    const speakOutput = 'Bonjour mémé !';

    // The response builder contains is an object that handles generating the
    // JSON response that your skill returns.
    return handlerInput.responseBuilder
      .speak(speakOutput) // The text passed to speak, is what Alexa will say.
      .getResponse();
  },
};

const MyFavoriteLanguageHandler = {
  canHandle(handlerInput) { 
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
    	&& handlerInput.requestEnvelope.request.intent.name === 'myFavoriteLanguageIntent';
  },
  handle(handlerInput){
    const speakOutput = 'Your favorite language is C#';
    
    return handlerInput.responseBuilder
    	.speak(speakOutput)
    	.getResponse();
  }
};

const HelpHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const speakOutput = 'You can say hello to me!';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const CancelAndStopHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'IntentRequest'
      && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
        || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const speakOutput = 'Goodbye!';

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    console.log(`Error handled: ${error.message}`);
    console.log(error.trace);

    return handlerInput.responseBuilder
      .speak('erreur')
      .getResponse();
  },
};

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    LaunchRequestHandler,
    GetJokeHandler,
    PostDataHandler,
    HelloHandler,
  	MyFavoriteLanguageHandler,
    HelpHandler,
    CancelAndStopHandler,
    SessionEndedRequestHandler,
    BadHandler,
    GoodHandler,
    ClosePlugHandler,
    OpenPlugHandler,
    AlarmRequestHandler
    
  )
  .addErrorHandlers(ErrorHandler)
  .lambda();

